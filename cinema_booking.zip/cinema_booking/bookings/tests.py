from django.utils.crypto import get_random_string
TEST_PASSWORD = get_random_string(24)
from concurrent.futures import ThreadPoolExecutor
from datetime import timedelta
from decimal import Decimal
from unittest.mock import patch
from django.contrib.auth.models import User
from django.core.files.storage import default_storage
from django.db import connections
from django.test import Client, TestCase, TransactionTestCase, skipUnlessDBFeature
from django.utils import timezone
from movies.models import Genre, Language, Movie, Review
from theaters.models import City, Theater, Screen, SeatCategory, Seat, Show
from .models import Booking, ShowSeat
from .services import create_pending_booking, release_expired_show_seats

class CinemaTestMixin:
    def setUp(self):
        self.user = User.objects.create_user(username="parth", password="TEST_PASSWORD", email="user@example.com")
        self.other = User.objects.create_user(username="other", password="TEST_PASSWORD", email="other@example.com")
        city = City.objects.create(name="Pune", slug="pune")
        theater = Theater.objects.create(name="Test Cinema", slug="test-cinema", city=city, address="Test")
        screen = Screen.objects.create(theater=theater, name="Screen 1")
        category = SeatCategory.objects.create(name="Standard")
        self.seat = Seat.objects.create(screen=screen, row_label="A", number=1, category=category, base_price=Decimal("200"))
        movie = Movie.objects.create(title="Test Movie", slug="test-movie", description="Test", duration_minutes=100, certification="U", release_date=timezone.now().date())
        movie.genres.add(Genre.objects.create(name="Drama", slug="drama")); movie.languages.add(Language.objects.create(name="English"))
        self.show = Show.objects.create(movie=movie, theater=theater, screen=screen, start_time=timezone.now()+timedelta(hours=2), end_time=timezone.now()+timedelta(hours=4), price=Decimal("200"))

class AuthenticationTests(CinemaTestMixin, TestCase):
    def test_register_login_and_profile(self):
        client = Client(); response = client.post("/accounts/register/", {"first_name":"New", "last_name":"User", "username":"newuser", "email":"new@example.com", "password1":"TEST_PASSWORD", "password2":"TEST_PASSWORD"})
        self.assertEqual(response.status_code, 302); self.assertTrue(User.objects.filter(username="newuser").exists())
        self.assertEqual(client.get("/accounts/profile/").status_code, 200)
    def test_booking_history_is_private(self):
        client = Client(); client.login(username="parth", password="TEST_PASSWORD")
        response = client.get("/bookings/history/"); self.assertEqual(response.status_code, 200)

class BookingTests(CinemaTestMixin, TestCase):
    @patch("bookings.services.create_razorpay_order")
    def test_seat_is_held_transactionally(self, create_order):
        create_order.return_value = type("P", (), {"order_id":"order_test"})()
        booking, _ = create_pending_booking(self.user, self.show, [self.seat.id])
        row = ShowSeat.objects.get(show=self.show, seat=self.seat)
        self.assertEqual(row.status, ShowSeat.Status.HELD); self.assertEqual(row.hold_token, booking.hold_token)
        with self.assertRaises(Exception): create_pending_booking(self.other, self.show, [self.seat.id])
    @patch("bookings.services.create_razorpay_order")
    def test_expired_hold_releases(self, create_order):
        create_order.return_value = type("P", (), {"order_id":"order_test"})()
        booking, _ = create_pending_booking(self.user, self.show, [self.seat.id])
        ShowSeat.objects.filter(show=self.show, seat=self.seat).update(hold_expires_at=timezone.now()-timedelta(seconds=1))
        release_expired_show_seats(self.show.id)
        self.assertEqual(ShowSeat.objects.get(pk=ShowSeat.objects.get(show=self.show, seat=self.seat).pk).status, ShowSeat.Status.AVAILABLE)
        self.assertEqual(Booking.objects.get(pk=booking.pk).status, Booking.Status.PENDING)
    @patch("bookings.services.create_razorpay_order")
    def test_booking_ownership(self, create_order):
        create_order.return_value = type("P", (), {"order_id":"order_test"})()
        booking, _ = create_pending_booking(self.user, self.show, [self.seat.id])
        client=Client(); client.login(username="other", password="TEST_PASSWORD")
        self.assertEqual(client.get(f"/bookings/{booking.reference}/").status_code, 404)

@skipUnlessDBFeature("supports_transactions")
class ConcurrentSeatReservationTests(CinemaTestMixin, TransactionTestCase):
    reset_sequences = True
    @patch("bookings.services.create_razorpay_order")
    def test_same_seat_cannot_be_reserved_twice(self, create_order):
        create_order.return_value = type("P", (), {"order_id":"order_test"})()
        def attempt(username):
            connections.close_all()
            user = User.objects.get(username=username)
            try:
                create_pending_booking(user, self.show, [self.seat.id]); return True
            except Exception:
                return False
        with ThreadPoolExecutor(max_workers=2) as pool:
            results=list(pool.map(attempt, ["parth", "other"]))
        self.assertEqual(results.count(True), 1)
