from django import forms
class SeatSelectionForm(forms.Form):
    seat_ids = forms.CharField(widget=forms.HiddenInput())
    def clean_seat_ids(self):
        raw = self.cleaned_data["seat_ids"]
        try:
            values = [int(x) for x in raw.split(",") if x.strip()]
        except ValueError:
            raise forms.ValidationError("Invalid seat selection.")
        if not values or len(values) > 12 or len(set(values)) != len(values):
            raise forms.ValidationError("Select between 1 and 12 unique seats.")
        return values
