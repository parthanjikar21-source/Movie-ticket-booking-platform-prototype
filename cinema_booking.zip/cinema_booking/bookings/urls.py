from django.urls import path
from .views import select_seats, create_booking, update_booking_seats, booking_history, booking_detail, confirmation, payment_history, ticket_history
urlpatterns = [
    path("show/<int:show_id>/seats/", select_seats, name="seat_selection"),
    path("show/<int:show_id>/create/", create_booking, name="create_booking"),
    path("<str:reference>/seats/", update_booking_seats, name="update_booking_seats"),
    path("history/", booking_history, name="booking_history"),
    path("payments/", payment_history, name="payment_history"),
    path("tickets/", ticket_history, name="ticket_history"),
    path("<str:reference>/", booking_detail, name="booking_detail"),
    path("<str:reference>/confirmation/", confirmation, name="booking_confirmation"),
]
