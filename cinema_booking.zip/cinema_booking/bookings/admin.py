from django.contrib import admin
from .models import ShowSeat, Booking, BookingSeat
@admin.register(ShowSeat)
class ShowSeatAdmin(admin.ModelAdmin):
    list_display = ("show", "seat", "status", "held_by", "hold_expires_at")
    list_filter = ("status", "show__theater")
    search_fields = ("show__movie__title", "seat__row_label")
@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ("reference", "user", "show", "quantity", "total_amount", "status", "created_at")
    list_filter = ("status", "created_at", "show__theater")
    search_fields = ("reference", "user__username", "user__email")
    readonly_fields = ("reference", "hold_token")
@admin.register(BookingSeat)
class BookingSeatAdmin(admin.ModelAdmin):
    list_display = ("booking", "show_seat", "price")
