import uuid
from django.contrib.auth.models import User
from django.db import models
from django.utils import timezone
from theaters.models import Show, Seat

def booking_reference():
    return uuid.uuid4().hex[:16].upper()

class ShowSeat(models.Model):
    class Status(models.TextChoices):
        AVAILABLE = "available", "Available"
        HELD = "held", "Temporarily reserved"
        BOOKED = "booked", "Booked"
    show = models.ForeignKey(Show, on_delete=models.CASCADE, related_name="show_seats")
    seat = models.ForeignKey(Seat, on_delete=models.CASCADE, related_name="show_seats")
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.AVAILABLE, db_index=True)
    held_by = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL, related_name="held_show_seats")
    hold_token = models.UUIDField(null=True, blank=True, db_index=True)
    hold_expires_at = models.DateTimeField(null=True, blank=True, db_index=True)
    class Meta:
        constraints = [models.UniqueConstraint(fields=["show", "seat"], name="unique_show_seat")]
        indexes = [models.Index(fields=["show", "status"]), models.Index(fields=["show", "hold_expires_at"]), models.Index(fields=["hold_token"])]
    @property
    def is_held_active(self): return self.status == self.Status.HELD and self.hold_expires_at and self.hold_expires_at > timezone.now()
    def __str__(self): return f"{self.show_id}:{self.seat.label}"

class Booking(models.Model):
    class Status(models.TextChoices):
        PENDING = "pending", "Pending payment"
        CONFIRMED = "confirmed", "Confirmed"
        CANCELLED = "cancelled", "Cancelled"
        FAILED = "failed", "Failed"
        EXPIRED = "expired", "Expired"
    reference = models.CharField(max_length=24, unique=True, editable=False, default=booking_reference)
    user = models.ForeignKey(User, on_delete=models.PROTECT, related_name="bookings")
    show = models.ForeignKey(Show, on_delete=models.PROTECT, related_name="bookings")
    quantity = models.PositiveSmallIntegerField()
    ticket_amount = models.DecimalField(max_digits=10, decimal_places=2)
    tax_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(max_length=12, choices=Status.choices, default=Status.PENDING, db_index=True)
    hold_token = models.UUIDField(default=uuid.uuid4, unique=True, editable=False)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    confirmed_at = models.DateTimeField(null=True, blank=True)
    updated_at = models.DateTimeField(auto_now=True)
    class Meta:
        indexes = [models.Index(fields=["user", "-created_at"]), models.Index(fields=["status", "-created_at"]), models.Index(fields=["show", "status"])]
    def __str__(self): return self.reference

class BookingSeat(models.Model):
    booking = models.ForeignKey(Booking, on_delete=models.CASCADE, related_name="booking_seats")
    show_seat = models.ForeignKey(ShowSeat, on_delete=models.PROTECT, related_name="booking_seats")
    price = models.DecimalField(max_digits=8, decimal_places=2)
    class Meta:
        constraints = [models.UniqueConstraint(fields=["booking", "show_seat"], name="unique_booking_show_seat")]
        indexes = [models.Index(fields=["booking"]), models.Index(fields=["show_seat"])]
    def __str__(self): return f"{self.booking.reference} {self.show_seat.seat.label}"
