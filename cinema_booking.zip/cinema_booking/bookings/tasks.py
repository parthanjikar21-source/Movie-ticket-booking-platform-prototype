from celery import shared_task
from django.db import transaction
from django.utils import timezone
from .models import Booking, ShowSeat

@shared_task
def expire_seat_holds():
    now = timezone.now()
    expired = list(Booking.objects.filter(status=Booking.Status.PENDING, created_at__lt=now).values_list("id", flat=True)[:1000])
    for booking_id in expired:
        with transaction.atomic():
            booking = Booking.objects.select_for_update().filter(pk=booking_id, status=Booking.Status.PENDING).first()
            if not booking: continue
            seats = ShowSeat.objects.select_for_update().filter(booking_seats__booking=booking).distinct()
            active_hold = seats.filter(status=ShowSeat.Status.HELD, hold_token=booking.hold_token, hold_expires_at__gt=now).exists()
            if active_hold: continue
            for seat in seats:
                if seat.status == ShowSeat.Status.HELD and seat.hold_token == booking.hold_token:
                    seat.status = ShowSeat.Status.AVAILABLE; seat.held_by = None; seat.hold_token = None; seat.hold_expires_at = None; seat.save(update_fields=["status", "held_by", "hold_token", "hold_expires_at"])
            booking.status = Booking.Status.EXPIRED; booking.save(update_fields=["status", "updated_at"])
