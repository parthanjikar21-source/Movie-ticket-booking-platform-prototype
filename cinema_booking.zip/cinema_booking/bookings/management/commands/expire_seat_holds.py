from django.core.management.base import BaseCommand
from bookings.tasks import expire_seat_holds
class Command(BaseCommand):
    help = "Release expired cinema seat holds."
    def handle(self, *args, **options):
        self.stdout.write(str(expire_seat_holds()))
