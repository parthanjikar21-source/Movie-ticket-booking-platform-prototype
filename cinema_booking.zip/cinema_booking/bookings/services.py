from decimal import Decimal
from django.conf import settings
from django.db import transaction
from django.utils import timezone
from datetime import timedelta
from django.core.exceptions import ValidationError
from .models import Booking, BookingSeat, ShowSeat
from payments.services import create_razorpay_order

def release_expired_show_seats(show_id=None):
    now = timezone.now()
    qs = ShowSeat.objects.filter(status=ShowSeat.Status.HELD, hold_expires_at__lte=now)
    if show_id: qs = qs.filter(show_id=show_id)
    return qs.update(status=ShowSeat.Status.AVAILABLE, held_by=None, hold_token=None, hold_expires_at=None)

def create_pending_booking(user, show, seat_ids):
    with transaction.atomic():
        release_expired_show_seats(show.id)
        rows = list(ShowSeat.objects.select_for_update().select_related("seat").filter(show=show, seat_id__in=seat_ids))
        if len(rows) != len(set(seat_ids)):
            raise ValidationError("One or more selected seats do not exist for this show.")
        now = timezone.now()
        unavailable = [row.seat.label for row in rows if row.status == ShowSeat.Status.BOOKED or (row.status == ShowSeat.Status.HELD and row.hold_expires_at and row.hold_expires_at > now)]
        if unavailable:
            raise ValidationError(f"These seats are no longer available: {', '.join(unavailable)}")
        total = sum((row.seat.base_price or show.price) for row in rows)
        if not total: total = show.price * len(rows)
        tax = (total * Decimal(str(settings.BOOKING_TAX_RATE))).quantize(Decimal("0.01"))
        booking = Booking.objects.create(user=user, show=show, quantity=len(rows), ticket_amount=total, tax_amount=tax, total_amount=total + tax)
        expires = now + timedelta(seconds=settings.SEAT_HOLD_SECONDS)
        for row in rows:
            row.status = ShowSeat.Status.HELD
            row.held_by = user
            row.hold_token = booking.hold_token
            row.hold_expires_at = expires
            row.save(update_fields=["status", "held_by", "hold_token", "hold_expires_at"])
            BookingSeat.objects.create(booking=booking, show_seat=row, price=row.seat.base_price or show.price)
        payment = create_razorpay_order(booking)
        return booking, payment

def replace_pending_booking_seats(booking, seat_ids):
    with transaction.atomic():
        booking = Booking.objects.select_for_update().get(pk=booking.pk, user=booking.user)
        if booking.status != Booking.Status.PENDING:
            raise ValidationError("This booking can no longer be modified.")
        release_expired_show_seats(booking.show_id)
        old = list(ShowSeat.objects.select_for_update().filter(booking_seats__booking=booking).distinct())
        for row in old:
            row.status = ShowSeat.Status.AVAILABLE; row.held_by = None; row.hold_token = None; row.hold_expires_at = None; row.save(update_fields=["status", "held_by", "hold_token", "hold_expires_at"])
        BookingSeat.objects.filter(booking=booking).delete()
        rows = list(ShowSeat.objects.select_for_update().select_related("seat").filter(show=booking.show, seat_id__in=seat_ids))
        if len(rows) != len(set(seat_ids)): raise ValidationError("Invalid seat selection.")
        now = timezone.now()
        if any(row.status == ShowSeat.Status.BOOKED or (row.status == ShowSeat.Status.HELD and row.hold_expires_at and row.hold_expires_at > now and row.hold_token != booking.hold_token) for row in rows): raise ValidationError("One or more selected seats are unavailable.")
        total = sum((row.seat.base_price or booking.show.price) for row in rows)
        tax = (total * Decimal(str(settings.BOOKING_TAX_RATE))).quantize(Decimal("0.01"))
        booking.quantity = len(rows); booking.ticket_amount = total; booking.tax_amount = tax; booking.total_amount = total + tax; booking.save(update_fields=["quantity", "ticket_amount", "tax_amount", "total_amount", "updated_at"])
        expires = now + timedelta(seconds=settings.SEAT_HOLD_SECONDS)
        for row in rows:
            row.status = ShowSeat.Status.HELD; row.held_by = booking.user; row.hold_token = booking.hold_token; row.hold_expires_at = expires; row.save(update_fields=["status", "held_by", "hold_token", "hold_expires_at"])
            BookingSeat.objects.create(booking=booking, show_seat=row, price=row.seat.base_price or booking.show.price)
        return booking
