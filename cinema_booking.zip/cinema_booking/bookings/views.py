from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ValidationError
from django.db.models import Prefetch
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST
from theaters.models import Show
from .forms import SeatSelectionForm
from .models import Booking, BookingSeat, ShowSeat
from .services import create_pending_booking, replace_pending_booking_seats, release_expired_show_seats

@login_required
def select_seats(request, show_id):
    show = get_object_or_404(Show.objects.select_related("movie", "theater", "screen"), pk=show_id, active=True)
    release_expired_show_seats(show.id)
    seats = ShowSeat.objects.filter(show=show).select_related("seat", "seat__category").order_by("seat__row_label", "seat__number")
    booking_ref = request.GET.get("booking")
    booking = None
    if booking_ref:
        booking = get_object_or_404(Booking, reference=booking_ref, user=request.user, show=show, status=Booking.Status.PENDING)
    return render(request, "bookings/seat_selection.html", {"show": show, "seats": seats, "form": SeatSelectionForm(), "booking": booking})

@login_required
@require_POST
def create_booking(request, show_id):
    show = get_object_or_404(Show, pk=show_id, active=True)
    form = SeatSelectionForm(request.POST)
    if not form.is_valid():
        messages.error(request, "Please select valid seats.")
        return redirect("seat_selection", show_id=show.id)
    try:
        booking, payment = create_pending_booking(request.user, show, form.cleaned_data["seat_ids"])
    except Exception as exc:
        messages.error(request, str(exc))
        return redirect("seat_selection", show_id=show.id)
    return redirect("payment_checkout", booking_reference=booking.reference)

@login_required
@require_POST
def update_booking_seats(request, reference):
    booking = get_object_or_404(Booking, reference=reference, user=request.user)
    form = SeatSelectionForm(request.POST)
    if not form.is_valid():
        messages.error(request, "Invalid seat selection.")
        return redirect("payment_checkout", booking_reference=reference)
    try:
        replace_pending_booking_seats(booking, form.cleaned_data["seat_ids"])
        messages.success(request, "Your seats have been updated.")
    except Exception as exc:
        messages.error(request, str(exc))
    return redirect("payment_checkout", booking_reference=reference)

@login_required
def booking_history(request):
    bookings = Booking.objects.filter(user=request.user).select_related("show__movie", "show__theater", "show__screen", "payment").prefetch_related("booking_seats__show_seat__seat")
    return render(request, "bookings/history.html", {"bookings": bookings})

@login_required
def booking_detail(request, reference):
    booking = get_object_or_404(Booking.objects.select_related("show__movie", "show__theater", "show__screen", "payment", "user").prefetch_related("booking_seats__show_seat__seat"), reference=reference, user=request.user)
    return render(request, "bookings/detail.html", {"booking": booking})

@login_required
def confirmation(request, reference):
    booking = get_object_or_404(Booking.objects.select_related("show__movie", "show__theater", "show__screen", "payment"), reference=reference, user=request.user)
    if booking.status != Booking.Status.CONFIRMED: return redirect("booking_detail", reference=reference)
    return render(request, "bookings/confirmation.html", {"booking": booking})

@login_required
def payment_history(request):
    from payments.models import Payment
    payments = Payment.objects.filter(booking__user=request.user).select_related("booking__show__movie")
    return render(request, "bookings/payment_history.html", {"payments": payments})

@login_required
def ticket_history(request):
    from tickets.models import Ticket
    tickets = Ticket.objects.filter(booking__user=request.user).select_related("booking__show__movie")
    return render(request, "bookings/ticket_history.html", {"tickets": tickets})
