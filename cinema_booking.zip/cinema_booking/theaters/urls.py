from django.urls import path
from .views import theater_list, theater_detail
urlpatterns = [path("", theater_list, name="theater_list"), path("<slug:slug>/", theater_detail, name="theater_detail")]
