from django.contrib import admin
from .models import City, Theater, Screen, SeatCategory, Seat, Show
class SeatInline(admin.TabularInline): model = Seat; extra = 0
@admin.register(Screen)
class ScreenAdmin(admin.ModelAdmin):
    list_display = ("theater", "name", "rows", "columns")
    inlines = [SeatInline]
@admin.register(Show)
class ShowAdmin(admin.ModelAdmin):
    list_display = ("movie", "theater", "screen", "start_time", "price", "active")
    list_filter = ("active", "theater", "screen", "start_time")
    search_fields = ("movie__title", "theater__name")
admin.site.register([City, Theater, SeatCategory, Seat])
