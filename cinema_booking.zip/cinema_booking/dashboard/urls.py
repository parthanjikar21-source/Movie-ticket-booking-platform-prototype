from django.urls import path
from .views import dashboard, export_bookings_csv
urlpatterns = [path("", dashboard, name="dashboard"), path("export/bookings.csv", export_bookings_csv, name="dashboard_export")]
