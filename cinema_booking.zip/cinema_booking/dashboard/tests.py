from django.utils.crypto import get_random_string
TEST_PASSWORD = get_random_string(24)
from django.contrib.auth.models import User
from django.test import TestCase, Client
class DashboardTests(TestCase):
    def test_non_staff_denied(self):
        u=User.objects.create_user(username="u",password="TEST_PASSWORD"); c=Client(); c.login(username="u",password="TEST_PASSWORD"); self.assertEqual(c.get("/dashboard/").status_code,302)
    def test_staff_can_access(self):
        u=User.objects.create_user(username="admin",password="TEST_PASSWORD",is_staff=True); c=Client(); c.login(username="admin",password="TEST_PASSWORD"); self.assertEqual(c.get("/dashboard/").status_code,200)
