import csv
from datetime import datetime, time
from decimal import Decimal
from django.contrib.admin.views.decorators import staff_member_required
from django.db.models import Count, Sum, Q, F, ExpressionWrapper, DecimalField
from django.db.models.functions import TruncDate, TruncHour
from django.http import HttpResponse
from django.shortcuts import render
from django.utils import timezone
from datetime import timedelta
from bookings.models import Booking, ShowSeat
from theaters.models import Theater

@staff_member_required
def dashboard(request):
    now = timezone.now()
    start_raw = request.GET.get("start")
    end_raw = request.GET.get("end")
    start = timezone.make_aware(datetime.strptime(start_raw, "%Y-%m-%d")) if start_raw else now.replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(days=30)
    end = timezone.make_aware(datetime.combine(datetime.strptime(end_raw, "%Y-%m-%d").date(), time.max)) if end_raw else now
    confirmed = Booking.objects.filter(status=Booking.Status.CONFIRMED, confirmed_at__range=(start, end))
    revenue = confirmed.aggregate(value=Sum("total_amount"))["value"] or Decimal("0")
    day_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    daily = Booking.objects.filter(status=Booking.Status.CONFIRMED, confirmed_at__range=(day_start, now)).aggregate(value=Sum("total_amount"))["value"] or Decimal("0")
    week_start = day_start - timedelta(days=day_start.weekday())
    weekly = Booking.objects.filter(status=Booking.Status.CONFIRMED, confirmed_at__range=(week_start, now)).aggregate(value=Sum("total_amount"))["value"] or Decimal("0")
    year_start = day_start.replace(month=1, day=1)
    yearly = Booking.objects.filter(status=Booking.Status.CONFIRMED, confirmed_at__range=(year_start, now)).aggregate(value=Sum("total_amount"))["value"] or Decimal("0")
    trends = confirmed.annotate(day=TruncDate("confirmed_at")).values("day").annotate(revenue=Sum("total_amount"), bookings=Count("id")).order_by("day")
    movies = confirmed.values("show__movie__title").annotate(bookings=Count("id"), revenue=Sum("total_amount")).order_by("-bookings")[:10]
    theaters = confirmed.values("show__theater__name").annotate(bookings=Count("id"), revenue=Sum("total_amount")).order_by("-revenue")[:10]
    peak_hours = confirmed.annotate(hour=TruncHour("show__start_time")).values("hour").annotate(bookings=Count("id")).order_by("hour")
    cancellations = Booking.objects.filter(status=Booking.Status.CANCELLED, created_at__range=(start, end)).count()
    failed = Booking.objects.filter(status=Booking.Status.FAILED, created_at__range=(start, end)).count()
    from django.contrib.auth.models import User
    from payments.models import Payment
    user_growth = User.objects.filter(date_joined__range=(start, end)).count()
    refunds = Payment.objects.filter(status=Payment.Status.REFUNDED, updated_at__range=(start, end)).aggregate(value=Sum("amount"))["value"] or Decimal("0")
    occupancy = []
    for theater in Theater.objects.filter(active=True):
        total = ShowSeat.objects.filter(show__theater=theater, show__start_time__range=(start, end)).count()
        booked = ShowSeat.objects.filter(show__theater=theater, show__start_time__range=(start, end), status=ShowSeat.Status.BOOKED).count()
        occupancy.append({"name": theater.name, "booked": booked, "total": total, "rate": round(booked * 100 / total, 1) if total else 0})
    return render(request, "dashboard/dashboard.html", {"revenue": revenue, "daily": daily, "weekly": weekly, "yearly": yearly, "trends": trends, "movies": movies, "theaters": theaters, "peak_hours": peak_hours, "cancellations": cancellations, "failed": failed, "user_growth": user_growth, "refunds": refunds, "occupancy": occupancy, "start": start.date(), "end": end.date()})

@staff_member_required
def export_bookings_csv(request):
    now = timezone.now()
    start_raw = request.GET.get("start"); end_raw = request.GET.get("end")
    qs = Booking.objects.filter(status=Booking.Status.CONFIRMED).select_related("user", "show__movie", "show__theater", "show__screen")
    if start_raw: qs = qs.filter(confirmed_at__date__gte=start_raw)
    if end_raw: qs = qs.filter(confirmed_at__date__lte=end_raw)
    response = HttpResponse(content_type="text/csv")
    response["Content-Disposition"] = 'attachment; filename="bookings.csv"'
    writer = csv.writer(response); writer.writerow(["Booking ID", "User", "Movie", "Theater", "Screen", "Quantity", "Amount", "Confirmed At"])
    for b in qs.iterator(chunk_size=2000): writer.writerow([b.reference, b.user.username, b.show.movie.title, b.show.theater.name, b.show.screen.name, b.quantity, b.total_amount, b.confirmed_at.isoformat() if b.confirmed_at else ""])
    return response
