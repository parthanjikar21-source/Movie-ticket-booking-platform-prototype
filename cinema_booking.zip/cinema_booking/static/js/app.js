document.addEventListener("DOMContentLoaded",()=>{document.querySelectorAll(".alert").forEach(el=>{setTimeout(()=>el.remove(),6000)})});
