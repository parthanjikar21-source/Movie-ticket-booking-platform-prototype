(() => {
const buttons=[...document.querySelectorAll(".seat:not(:disabled)")], selected=new Map();
(window.initialSelectedSeats||[]).forEach(id=>{const b=buttons.find(x=>Number(x.dataset.seatId)===Number(id));if(b){b.classList.add("selected");selected.set(String(id),b)}});
const sync=()=>{document.getElementById("seat_ids").value=[...selected.keys()].join(",");document.getElementById("selected-count").textContent=selected.size;document.getElementById("selected-total").textContent=[...selected.values()].reduce((s,b)=>s+Number(b.dataset.price||0),0).toFixed(2);document.getElementById("continue-button").disabled=selected.size===0};
buttons.forEach(b=>b.addEventListener("click",()=>{const id=String(b.dataset.seatId);if(selected.has(id)){selected.delete(id);b.classList.remove("selected")}else{if(selected.size>=12)return;b.classList.add("selected");selected.set(id,b)}sync()}));sync();
})();
