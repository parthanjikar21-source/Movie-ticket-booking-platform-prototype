from django.contrib.auth.models import User
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models
from django.db.models import Avg
from django.db.models.functions import Now

class Genre(models.Model):
    name = models.CharField(max_length=80, unique=True, db_index=True)
    slug = models.SlugField(max_length=90, unique=True)
    def __str__(self): return self.name

class Language(models.Model):
    name = models.CharField(max_length=80, unique=True, db_index=True)
    def __str__(self): return self.name

class Movie(models.Model):
    CERTIFICATIONS = [("U", "U"), ("UA", "UA"), ("A", "A"), ("S", "S")]
    title = models.CharField(max_length=200, db_index=True)
    slug = models.SlugField(max_length=220, unique=True)
    poster = models.ImageField(upload_to="movies/posters/", blank=True, null=True)
    description = models.TextField()
    trailer_url = models.URLField(blank=True)
    genres = models.ManyToManyField(Genre, related_name="movies", blank=True)
    languages = models.ManyToManyField(Language, related_name="movies", blank=True)
    duration_minutes = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    certification = models.CharField(max_length=5, choices=CERTIFICATIONS, default="U")
    release_date = models.DateField(db_index=True)
    is_published = models.BooleanField(default=True, db_index=True)
    view_count = models.PositiveBigIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    class Meta:
        indexes = [models.Index(fields=["is_published", "release_date"]), models.Index(fields=["title"]), models.Index(fields=["view_count"])]
    @property
    def average_rating(self):
        if hasattr(self, "avg_rating"):
            return self.avg_rating or 0
        return self.reviews.filter(is_reported=False).aggregate(value=Avg("rating"))["value"] or 0
    @property
    def trailer_embed_url(self):
        from urllib.parse import urlparse, parse_qs
        if not self.trailer_url: return ""
        parsed = urlparse(self.trailer_url)
        host = parsed.netloc.lower().replace("www.", "")
        if host in {"youtube.com", "m.youtube.com"}:
            video_id = parse_qs(parsed.query).get("v", [""])[0]
        elif host == "youtu.be":
            video_id = parsed.path.strip("/").split("/")[0]
        else:
            video_id = ""
        return f"https://www.youtube.com/embed/{video_id}" if video_id and len(video_id) <= 20 else ""
    def __str__(self): return self.title

class MovieImage(models.Model):
    movie = models.ForeignKey(Movie, on_delete=models.CASCADE, related_name="images")
    image = models.ImageField(upload_to="movies/gallery/")
    caption = models.CharField(max_length=160, blank=True)
    sort_order = models.PositiveIntegerField(default=0)
    class Meta:
        ordering = ["sort_order", "id"]

class CastMember(models.Model):
    name = models.CharField(max_length=150, unique=True)
    photo = models.ImageField(upload_to="cast/", blank=True, null=True)
    bio = models.TextField(blank=True)
    def __str__(self): return self.name

class MovieCast(models.Model):
    movie = models.ForeignKey(Movie, on_delete=models.CASCADE, related_name="cast_links")
    person = models.ForeignKey(CastMember, on_delete=models.CASCADE, related_name="movie_links")
    character_name = models.CharField(max_length=150, blank=True)
    billing_order = models.PositiveIntegerField(default=0)
    class Meta:
        ordering = ["billing_order", "id"]
        constraints = [models.UniqueConstraint(fields=["movie", "person"], name="unique_movie_cast")]

class Review(models.Model):
    movie = models.ForeignKey(Movie, on_delete=models.CASCADE, related_name="reviews")
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="movie_reviews")
    rating = models.PositiveSmallIntegerField(validators=[MinValueValidator(1), MaxValueValidator(5)])
    text = models.TextField(max_length=2000)
    is_reported = models.BooleanField(default=False, db_index=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    class Meta:
        ordering = ["-created_at"]
        constraints = [models.UniqueConstraint(fields=["movie", "user"], name="one_review_per_user_movie")]
        indexes = [models.Index(fields=["movie", "is_reported"]), models.Index(fields=["user", "movie"])]
    @property
    def verified_viewer(self):
        if hasattr(self, "verified_viewer_flag"):
            return self.verified_viewer_flag
        from bookings.models import Booking
        return Booking.objects.filter(user=self.user, show__movie=self.movie, status=Booking.Status.CONFIRMED, show__start_time__lt=Now()).exists()
