from django.contrib import admin
from .models import Genre, Language, Movie, MovieImage, CastMember, MovieCast, Review
class MovieImageInline(admin.TabularInline): model = MovieImage; extra = 1
class MovieCastInline(admin.TabularInline): model = MovieCast; extra = 1
@admin.register(Movie)
class MovieAdmin(admin.ModelAdmin):
    list_display = ("title", "release_date", "certification", "duration_minutes", "is_published", "view_count")
    list_filter = ("is_published", "certification", "release_date", "genres", "languages")
    search_fields = ("title", "description")
    prepopulated_fields = {"slug": ("title",)}
    filter_horizontal = ("genres", "languages")
    inlines = [MovieImageInline, MovieCastInline]
admin.site.register([Genre, Language, CastMember, Review])
