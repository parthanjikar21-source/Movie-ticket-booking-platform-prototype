from django.urls import path
from .views import movie_list, movie_detail, add_review, report_review
urlpatterns = [
    path("", movie_list, name="movie_list"),
    path("<slug:slug>/", movie_detail, name="movie_detail"),
    path("<slug:slug>/reviews/", add_review, name="add_review"),
    path("reviews/<int:review_id>/report/", report_review, name="report_review"),
]
