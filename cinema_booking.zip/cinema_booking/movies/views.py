from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.db.models import Avg, Count, Q, Exists, OuterRef
from django.db.models import Prefetch
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from datetime import timedelta
from django.views.decorators.http import require_POST
from .forms import ReviewForm
from .models import Genre, Language, Movie, Review
from theaters.models import City, Theater, Show
from bookings.models import Booking

def home(request):
    now = timezone.now()
    movies = Movie.objects.filter(is_published=True).annotate(avg_rating=Avg("reviews__rating", filter=Q(reviews__is_reported=False))).prefetch_related("genres", "languages").order_by("-view_count", "-release_date")[:8]
    recent = Movie.objects.filter(is_published=True, release_date__lte=now.date()).annotate(avg_rating=Avg("reviews__rating", filter=Q(reviews__is_reported=False))).order_by("-release_date")[:8]
    trending = Movie.objects.filter(is_published=True).annotate(bookings_count=Count("show__bookings", filter=Q(show__bookings__status=Booking.Status.CONFIRMED), distinct=True), avg_rating=Avg("reviews__rating", filter=Q(reviews__is_reported=False))).order_by("-bookings_count", "-view_count")[:8]
    recommended = Movie.objects.filter(is_published=True)
    if request.user.is_authenticated:
        history = Booking.objects.filter(user=request.user, status=Booking.Status.CONFIRMED).values_list("show__movie_id", flat=True)[:50]
        watched = Movie.objects.filter(pk__in=history)
        genre_ids = watched.values_list("genres__id", flat=True)
        language_ids = watched.values_list("languages__id", flat=True)
        recommended = recommended.filter(Q(genres__in=genre_ids) | Q(languages__in=language_ids)).exclude(pk__in=history).distinct().order_by("-view_count", "-release_date")[:8]
    if not recommended.exists():
        recommended = trending[:8]
    return render(request, "movies/home.html", {"movies": movies, "recent": recent, "trending": trending, "recommended": recommended})

def movie_list(request):
    qs = Movie.objects.filter(is_published=True).prefetch_related("genres", "languages")
    q = request.GET.get("q", "").strip()
    genre = request.GET.get("genre")
    language = request.GET.get("language")
    city = request.GET.get("city")
    theater = request.GET.get("theater")
    timing = request.GET.get("timing")
    rating = request.GET.get("rating")
    release = request.GET.get("release")
    sort = request.GET.get("sort", "popularity")
    if q: qs = qs.filter(title__icontains=q)
    if genre: qs = qs.filter(genres__slug=genre)
    if language: qs = qs.filter(languages__name__iexact=language)
    if city: qs = qs.filter(show__theater__city__slug=city, show__start_time__gte=timezone.now())
    if theater: qs = qs.filter(show__theater__slug=theater, show__start_time__gte=timezone.now())
    if timing:
        from django.db.models.functions import ExtractHour
        qs = qs.annotate(show_hour=ExtractHour("show__start_time")).filter(show_hour__gte=int(timing), show_hour__lt=int(timing)+4, show__start_time__gte=timezone.now())
    if rating: qs = qs.annotate(avg_rating=Avg("reviews__rating", filter=Q(reviews__is_reported=False))).filter(avg_rating__gte=float(rating))
    if release == "upcoming": qs = qs.filter(release_date__gte=timezone.now().date())
    elif release == "recent": qs = qs.filter(release_date__gte=timezone.now().date() - timedelta(days=60))
    qs = qs.distinct()
    if sort == "newest": qs = qs.order_by("-release_date")
    elif sort == "rating": qs = qs.annotate(avg_rating=Avg("reviews__rating", filter=Q(reviews__is_reported=False))).order_by("-avg_rating", "-release_date")
    elif sort == "price": qs = qs.annotate(min_price=MinShowPrice()).order_by("min_price")
    else: qs = qs.order_by("-view_count", "-release_date")
    paginator = Paginator(qs, 12)
    page = paginator.get_page(request.GET.get("page"))
    return render(request, "movies/movie_list.html", {"page": page, "genres": Genre.objects.all(), "languages": Language.objects.all(), "cities": City.objects.all(), "theaters": Theater.objects.filter(active=True).select_related("city"), "count": paginator.count})

def MinShowPrice():
    from django.db.models import Min
    return Min("show__price")

def movie_detail(request, slug):
    eligible_review_booking = Booking.objects.filter(user=OuterRef("user_id"), show__movie=OuterRef("movie_id"), status=Booking.Status.CONFIRMED, show__start_time__lt=timezone.now())
    review_qs = Review.objects.filter(is_reported=False).select_related("user").annotate(verified_viewer_flag=Exists(eligible_review_booking))
    movie = get_object_or_404(Movie.objects.prefetch_related("genres", "languages", "images", "cast_links__person", Prefetch("reviews", queryset=review_qs)), slug=slug, is_published=True)
    Movie.objects.filter(pk=movie.pk).update(view_count=movie.view_count + 1)
    shows = Show.objects.filter(movie=movie, start_time__gte=timezone.now()).select_related("theater", "screen", "theater__city").order_by("start_time")[:30]
    similar = Movie.objects.filter(is_published=True, genres__in=movie.genres.all()).exclude(pk=movie.pk).distinct().order_by("-view_count")[:6]
    review_form = ReviewForm()
    return render(request, "movies/movie_detail.html", {"movie": movie, "shows": shows, "similar": similar, "review_form": review_form})

@login_required
@require_POST
def add_review(request, slug):
    movie = get_object_or_404(Movie, slug=slug, is_published=True)
    eligible = Booking.objects.filter(user=request.user, show__movie=movie, status=Booking.Status.CONFIRMED, show__start_time__lt=timezone.now()).exists()
    if not eligible:
        messages.error(request, "You can review a movie only after completing an eligible booking.")
        return redirect("movie_detail", slug=slug)
    review = Review.objects.filter(movie=movie, user=request.user).first()
    form = ReviewForm(request.POST, instance=review)
    if form.is_valid():
        obj = form.save(commit=False); obj.movie = movie; obj.user = request.user; obj.save(); messages.success(request, "Review saved.")
    return redirect("movie_detail", slug=slug)

@login_required
@require_POST
def report_review(request, review_id):
    review = get_object_or_404(Review, pk=review_id)
    if review.user_id != request.user.id:
        review.is_reported = True; review.save(update_fields=["is_reported"]); messages.success(request, "Review reported.")
    return redirect("movie_detail", slug=review.movie.slug)
