from django.utils.crypto import get_random_string
TEST_PASSWORD = get_random_string(24)
from datetime import timedelta
from django.contrib.auth.models import User
from django.test import TestCase, Client
from django.utils import timezone
from .models import Movie, Genre, Language, Review
from theaters.models import City, Theater, Screen, SeatCategory, Seat, Show
from bookings.models import Booking, BookingSeat, ShowSeat
from decimal import Decimal

class MovieTests(TestCase):
    def setUp(self):
        self.user=User.objects.create_user(username="u", password="TEST_PASSWORD", email="u@example.com")
        self.genre=Genre.objects.create(name="Action", slug="action"); lang=Language.objects.create(name="English")
        self.movie=Movie.objects.create(title="Searchable Film", slug="searchable-film", description="Desc", duration_minutes=100, certification="UA", release_date=timezone.now().date())
        self.movie.genres.add(self.genre); self.movie.languages.add(lang)
        city=City.objects.create(name="Pune", slug="pune"); theater=Theater.objects.create(name="Cinema", slug="cinema", city=city, address="A")
        screen=Screen.objects.create(theater=theater, name="One"); cat=SeatCategory.objects.create(name="Standard"); seat=Seat.objects.create(screen=screen,row_label="A",number=1,category=cat,base_price=Decimal("200"))
        self.show=Show.objects.create(movie=self.movie,theater=theater,screen=screen,start_time=timezone.now()+timedelta(hours=2),end_time=timezone.now()+timedelta(hours=4),price=200)
    def test_movie_detail_and_search(self):
        c=Client(); self.assertEqual(c.get("/movies/searchable-film/").status_code,200); self.assertContains(c.get("/movies/?q=Searchable"), "Searchable Film")
    def test_review_requires_completed_booking(self):
        c=Client(); c.login(username="u", password="TEST_PASSWORD")
        response=c.post("/movies/searchable-film/reviews/", {"rating":5,"text":"Great"}); self.assertEqual(response.status_code,302); self.assertFalse(Review.objects.exists())
        booking=Booking.objects.create(user=self.user,show=self.show,quantity=1,ticket_amount=200,total_amount=200,status=Booking.Status.CONFIRMED,confirmed_at=timezone.now())
        self.show.start_time=timezone.now()-timedelta(hours=2); self.show.end_time=timezone.now()-timedelta(hours=1); self.show.save()
        ShowSeat.objects.create(show=self.show,seat=self.show.screen.seats.first(),status=ShowSeat.Status.BOOKED); BookingSeat.objects.create(booking=booking,show_seat=ShowSeat.objects.last(),price=200)
        response=c.post("/movies/searchable-film/reviews/", {"rating":5,"text":"Great"}); self.assertEqual(response.status_code,302); self.assertTrue(Review.objects.exists())
