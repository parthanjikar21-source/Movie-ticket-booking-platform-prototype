from django.contrib import admin
from .models import Payment, WebhookEvent
@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ("order_id", "booking", "amount", "status", "payment_id", "created_at")
    list_filter = ("status", "provider")
    search_fields = ("order_id", "payment_id", "booking__reference")
@admin.register(WebhookEvent)
class WebhookEventAdmin(admin.ModelAdmin):
    list_display = ("event_id", "event_type", "processed", "received_at")
    readonly_fields = ("payload",)
