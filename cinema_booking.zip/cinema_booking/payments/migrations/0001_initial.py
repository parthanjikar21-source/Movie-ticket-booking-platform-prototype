from django.db import migrations, models
import django.db.models.deletion

class Migration(migrations.Migration):
    initial = True
    dependencies = [("bookings", "0001_initial")]
    operations = [
        migrations.CreateModel(name="Payment", fields=[("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")), ("provider", models.CharField(default="razorpay", max_length=30)), ("order_id", models.CharField(max_length=100, unique=True)), ("payment_id", models.CharField(blank=True, max_length=100, null=True, unique=True)), ("signature", models.CharField(blank=True, max_length=255)), ("amount", models.DecimalField(decimal_places=2, max_digits=10)), ("currency", models.CharField(default="INR", max_length=5)), ("status", models.CharField(choices=[("created","Created"),("authorized","Authorized"),("captured","Captured"),("failed","Failed"),("refunded","Refunded")], db_index=True, default="created", max_length=12)), ("raw_payload", models.JSONField(blank=True, default=dict)), ("created_at", models.DateTimeField(auto_now_add=True)), ("updated_at", models.DateTimeField(auto_now=True)), ("booking", models.OneToOneField(on_delete=django.db.models.deletion.PROTECT, related_name="payment", to="bookings.booking"))], options={"indexes":[models.Index(fields=["status","-created_at"]), models.Index(fields=["payment_id"])]}),
        migrations.CreateModel(name="WebhookEvent", fields=[("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")), ("event_id", models.CharField(max_length=160, unique=True)), ("event_type", models.CharField(max_length=100)), ("processed", models.BooleanField(default=False)), ("payload", models.JSONField(default=dict)), ("received_at", models.DateTimeField(auto_now_add=True)), ("processed_at", models.DateTimeField(blank=True, null=True))], options={"indexes":[models.Index(fields=["event_type","received_at"])]}),
    ]
