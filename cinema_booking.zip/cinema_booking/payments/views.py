import json
import hmac
import hashlib
from django.conf import settings
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse, HttpResponseBadRequest
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from bookings.models import Booking
from .models import Payment, WebhookEvent
from .services import confirm_booking_from_payment, capture_payment_from_webhook, mark_payment_failed

@login_required
def checkout(request, booking_reference):
    booking = get_object_or_404(Booking.objects.select_related("show__movie", "show__theater", "show__screen").prefetch_related("booking_seats__show_seat__seat"), reference=booking_reference, user=request.user)
    if booking.status != Booking.Status.PENDING: return redirect("booking_detail", reference=booking.reference)
    return render(request, "payments/checkout.html", {"booking": booking, "payment": booking.payment, "razorpay_key": settings.RAZORPAY_KEY_ID})

@login_required
@require_POST
def verify_payment(request):
    booking_ref = request.POST.get("booking_reference")
    booking = get_object_or_404(Booking, reference=booking_ref, user=request.user)
    try:
        booking = confirm_booking_from_payment(request.POST["razorpay_payment_id"], request.POST["razorpay_order_id"], request.POST["razorpay_signature"])
    except Exception as exc:
        messages.error(request, f"Payment verification failed: {exc}")
        return redirect("payment_checkout", booking_reference=booking.reference)
    from tickets.tasks import generate_and_email_ticket
    generate_and_email_ticket.delay(booking.pk)
    return redirect("booking_confirmation", reference=booking.reference)

@csrf_exempt
@require_POST
def razorpay_webhook(request):
    secret = settings.RAZORPAY_WEBHOOK_SECRET
    if not secret: return HttpResponseBadRequest("Webhook secret is not configured")
    signature = request.headers.get("X-Razorpay-Signature", "")
    expected = hmac.new(secret.encode(), request.body, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(signature, expected): return HttpResponseBadRequest("Invalid signature")
    try: payload = json.loads(request.body)
    except json.JSONDecodeError: return HttpResponseBadRequest("Invalid JSON")
    event_id = request.headers.get("X-Razorpay-Event-Id") or hashlib.sha256(request.body).hexdigest()
    event_type = payload.get("event", "")
    event, created = WebhookEvent.objects.get_or_create(event_id=event_id, defaults={"event_type": event_type, "payload": payload})
    if not created and event.processed: return JsonResponse({"ok": True, "duplicate": True})
    if event_type == "payment.captured":
        entity = payload.get("payload", {}).get("payment", {}).get("entity", {})
        order_id = entity.get("order_id"); payment_id = entity.get("id")
        if order_id and payment_id:
            try:
                capture_payment_from_webhook(payment_id, order_id, payload)
            except Exception:
                pass
    elif event_type == "payment.failed":
        entity = payload.get("payload", {}).get("payment", {}).get("entity", {})
        if entity.get("order_id"): mark_payment_failed(entity["order_id"], payload)
    event.processed = True; event.processed_at = timezone.now(); event.save(update_fields=["processed", "processed_at"])
    return JsonResponse({"ok": True})

@login_required
@require_POST
def cancel_checkout(request, booking_reference):
    from django.db import transaction
    booking = get_object_or_404(Booking, reference=booking_reference, user=request.user)
    with transaction.atomic():
        booking = Booking.objects.select_for_update().get(pk=booking.pk)
        if booking.status == Booking.Status.PENDING:
            booking.status = Booking.Status.CANCELLED; booking.save(update_fields=["status", "updated_at"])
            from bookings.models import ShowSeat
            seats = ShowSeat.objects.select_for_update().filter(booking_seats__booking=booking).distinct()
            for seat in seats:
                if seat.status == ShowSeat.Status.HELD and seat.hold_token == booking.hold_token:
                    seat.status = ShowSeat.Status.AVAILABLE; seat.held_by = None; seat.hold_token = None; seat.hold_expires_at = None; seat.save(update_fields=["status", "held_by", "hold_token", "hold_expires_at"])
    return JsonResponse({"ok": True})
