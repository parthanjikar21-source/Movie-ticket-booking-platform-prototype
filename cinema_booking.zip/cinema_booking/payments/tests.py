from unittest.mock import patch
from django.test import TestCase
from .models import Payment, WebhookEvent
from .services import mark_payment_failed
from bookings.models import Booking, ShowSeat
from bookings.tests import CinemaTestMixin

class PaymentTests(CinemaTestMixin, TestCase):
    def test_failed_payment_releases_hold(self):
        booking=Booking.objects.create(user=self.user,show=self.show,quantity=1,ticket_amount=200,total_amount=200)
        row=ShowSeat.objects.get(show=self.show,seat=self.seat); row.status=ShowSeat.Status.HELD; row.hold_token=booking.hold_token; row.held_by=self.user; from django.utils import timezone; from datetime import timedelta; row.hold_expires_at=timezone.now()+timedelta(minutes=2); row.save()
        from bookings.models import BookingSeat; BookingSeat.objects.create(booking=booking,show_seat=row,price=200)
        payment=Payment.objects.create(booking=booking,order_id="order_1",amount=200)
        mark_payment_failed("order_1", {"event":"payment.failed"})
        row.refresh_from_db(); booking.refresh_from_db(); payment.refresh_from_db()
        self.assertEqual(row.status, ShowSeat.Status.AVAILABLE); self.assertEqual(booking.status, Booking.Status.FAILED); self.assertEqual(payment.status, Payment.Status.FAILED)
    @patch("payments.views.capture_payment_from_webhook")
    def test_duplicate_webhook_is_idempotent(self, capture):
        import json, hmac, hashlib
        from django.conf import settings
        from django.test import Client, override_settings
        payload={"event":"payment.captured","payload":{"payment":{"entity":{"order_id":"order_x","id":"pay_x"}}}}
        secret="webhook-secret"; body=json.dumps(payload).encode(); sig=hmac.new(secret.encode(),body,hashlib.sha256).hexdigest()
        with override_settings(RAZORPAY_WEBHOOK_SECRET=secret):
            c=Client(); first=c.post("/payments/webhook/razorpay/",body,content_type="application/json",HTTP_X_RAZORPAY_SIGNATURE=sig,HTTP_X_RAZORPAY_EVENT_ID="evt_1"); second=c.post("/payments/webhook/razorpay/",body,content_type="application/json",HTTP_X_RAZORPAY_SIGNATURE=sig,HTTP_X_RAZORPAY_EVENT_ID="evt_1")
        self.assertEqual(first.status_code,200); self.assertEqual(second.status_code,200); self.assertEqual(WebhookEvent.objects.filter(event_id="evt_1").count(),1)
