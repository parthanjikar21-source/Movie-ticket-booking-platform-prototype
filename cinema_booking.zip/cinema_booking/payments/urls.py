from django.urls import path
from .views import checkout, verify_payment, razorpay_webhook, cancel_checkout
urlpatterns = [
    path("checkout/<str:booking_reference>/", checkout, name="payment_checkout"),
    path("verify/", verify_payment, name="payment_verify"),
    path("webhook/razorpay/", razorpay_webhook, name="razorpay_webhook"), path("checkout/<str:booking_reference>/cancel/", cancel_checkout, name="cancel_checkout"),
]
