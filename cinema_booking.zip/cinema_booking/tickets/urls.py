from django.urls import path
from .views import download_ticket, verify_ticket
urlpatterns = [path("<str:reference>/download/", download_ticket, name="ticket_download"), path("verify/<str:reference>/<uuid:token>/", verify_ticket, name="ticket_verify")]
