from io import BytesIO
import qrcode
from django.conf import settings
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
from django.urls import reverse
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.lib import colors
from .models import Ticket

def qr_bytes(data):
    image = qrcode.make(data)
    buffer = BytesIO(); image.save(buffer, format="PNG"); return buffer.getvalue()

def build_ticket_pdf(booking, ticket):
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=18*mm, leftMargin=18*mm, topMargin=18*mm, bottomMargin=18*mm)
    styles = getSampleStyleSheet()
    title = ParagraphStyle("TicketTitle", parent=styles["Title"], fontSize=22, leading=26, spaceAfter=10)
    body = ParagraphStyle("TicketBody", parent=styles["BodyText"], fontSize=10, leading=14)
    story = [Paragraph("CINEMA TICKET", title), Paragraph(f"<b>{booking.show.movie.title}</b>", styles["Heading2"]), Spacer(1, 6)]
    data = [
        ["Booking ID", booking.reference], ["Theater", booking.show.theater.name], ["Screen", booking.show.screen.name],
        ["Show", booking.show.start_time.strftime("%d %b %Y, %I:%M %p")], ["Seats", ", ".join(x.show_seat.seat.label for x in booking.booking_seats.all())],
        ["Payment", getattr(booking.payment, "payment_id", "") or getattr(booking.payment, "order_id", "")], ["Total", f"INR {booking.total_amount:.2f}"],
    ]
    table = Table(data, colWidths=[35*mm, 125*mm])
    table.setStyle(TableStyle([("BACKGROUND", (0,0), (0,-1), colors.HexColor("#eeeeee")), ("GRID", (0,0), (-1,-1), .5, colors.HexColor("#cccccc")), ("VALIGN", (0,0), (-1,-1), "TOP"), ("FONTNAME", (0,0), (-1,-1), "Helvetica"), ("FONTSIZE", (0,0), (-1,-1), 9), ("BOTTOMPADDING", (0,0), (-1,-1), 7), ("TOPPADDING", (0,0), (-1,-1), 7)]))
    story += [table, Spacer(1, 12)]
    qr_data = f"cinema-ticket:{booking.reference}:{ticket.verification_token}"
    qr = Image(BytesIO(qr_bytes(qr_data)), width=38*mm, height=38*mm)
    story += [qr, Spacer(1, 6), Paragraph("Present this QR code at the theater. Keep your booking ID and ticket private.", body)]
    doc.build(story)
    return buffer.getvalue()

def generate_ticket(booking):
    ticket, _ = Ticket.objects.get_or_create(booking=booking)
    if not ticket.pdf_file:
        content = build_ticket_pdf(booking, ticket)
        ticket.pdf_file.save(f"{booking.reference}.pdf", ContentFile(content), save=True)
    return ticket

def ticket_pdf_bytes(ticket):
    if not ticket.pdf_file: return None
    with ticket.pdf_file.open("rb") as fh: return fh.read()
