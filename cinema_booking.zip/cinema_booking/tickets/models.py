import uuid
from django.db import models
from bookings.models import Booking

class Ticket(models.Model):
    booking = models.OneToOneField(Booking, on_delete=models.CASCADE, related_name="ticket")
    verification_token = models.UUIDField(default=uuid.uuid4, unique=True, editable=False)
    pdf_file = models.FileField(upload_to="tickets/%Y/%m/", blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    emailed_at = models.DateTimeField(null=True, blank=True)
    def __str__(self): return f"Ticket {self.booking.reference}"
