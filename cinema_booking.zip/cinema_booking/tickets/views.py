from django.contrib.auth.decorators import login_required
from django.http import FileResponse, Http404
from django.shortcuts import get_object_or_404, render
from bookings.models import Booking
from .models import Ticket
from .services import generate_ticket

@login_required
def download_ticket(request, reference):
    booking = get_object_or_404(Booking.objects.select_related("show__movie", "show__theater", "show__screen", "payment").prefetch_related("booking_seats__show_seat__seat"), reference=reference, user=request.user, status=Booking.Status.CONFIRMED)
    ticket = generate_ticket(booking)
    if not ticket.pdf_file: raise Http404
    response = FileResponse(ticket.pdf_file.open("rb"), content_type="application/pdf")
    response["Content-Disposition"] = f'attachment; filename="{booking.reference}.pdf"'
    return response

def verify_ticket(request, reference, token):
    ticket = get_object_or_404(Ticket.objects.select_related("booking__show__movie", "booking__show__theater", "booking__show__screen"), booking__reference=reference, verification_token=token)
    booking = ticket.booking
    return render(request, "tickets/verify.html", {"ticket": ticket, "booking": booking, "valid": booking.status == Booking.Status.CONFIRMED})
