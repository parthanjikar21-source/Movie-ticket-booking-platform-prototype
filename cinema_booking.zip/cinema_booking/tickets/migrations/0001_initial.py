from django.db import migrations, models
import django.db.models.deletion
import uuid

class Migration(migrations.Migration):
    initial = True
    dependencies = [("bookings", "0001_initial")]
    operations = [migrations.CreateModel(name="Ticket", fields=[("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")), ("verification_token", models.UUIDField(default=uuid.uuid4, editable=False, unique=True)), ("pdf_file", models.FileField(blank=True, null=True, upload_to="tickets/%Y/%m/")), ("created_at", models.DateTimeField(auto_now_add=True)), ("emailed_at", models.DateTimeField(blank=True, null=True)), ("booking", models.OneToOneField(on_delete=django.db.models.deletion.CASCADE, related_name="ticket", to="bookings.booking"))])]
