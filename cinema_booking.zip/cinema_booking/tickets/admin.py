from django.contrib import admin
from .models import Ticket
@admin.register(Ticket)
class TicketAdmin(admin.ModelAdmin):
    list_display = ("booking", "created_at", "emailed_at")
    search_fields = ("booking__reference", "booking__user__username")
