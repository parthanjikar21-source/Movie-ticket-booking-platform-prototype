from django.utils.crypto import get_random_string
TEST_PASSWORD = get_random_string(24)
from datetime import timedelta
from decimal import Decimal
from django.contrib.auth.models import User
from django.test import TestCase
from django.utils import timezone
from theaters.models import City, Theater, Screen, SeatCategory, Seat, Show
from movies.models import Movie
from bookings.models import Booking, BookingSeat, ShowSeat
from .services import build_ticket_pdf, generate_ticket

class TicketTests(TestCase):
    def test_pdf_and_qr_generation(self):
        user=User.objects.create_user(username="u", password="TEST_PASSWORD", email="u@example.com")
        city=City.objects.create(name="Pune",slug="pune"); theater=Theater.objects.create(name="T",slug="t",city=city,address="A"); screen=Screen.objects.create(theater=theater,name="S"); cat=SeatCategory.objects.create(name="Standard"); seat=Seat.objects.create(screen=screen,row_label="A",number=1,category=cat,base_price=Decimal("200")); movie=Movie.objects.create(title="M",slug="m",description="D",duration_minutes=100,certification="U",release_date=timezone.now().date()); show=Show.objects.create(movie=movie,theater=theater,screen=screen,start_time=timezone.now()+timedelta(hours=1),end_time=timezone.now()+timedelta(hours=3),price=200); booking=Booking.objects.create(user=user,show=show,quantity=1,ticket_amount=200,total_amount=200,status=Booking.Status.CONFIRMED); ss=ShowSeat.objects.get(show=show,seat=seat); BookingSeat.objects.create(booking=booking,show_seat=ss,price=200); ticket=generate_ticket(booking)
        self.assertTrue(ticket.pdf_file.name); self.assertGreater(ticket.pdf_file.size,100)
